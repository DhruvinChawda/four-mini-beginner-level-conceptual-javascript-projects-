const form = document.querySelector('form')

form.addEventListener('submit',function(eve){
    eve.preventDefault()
    const height = parseInt(document.querySelector('#height').value)
    const weight = parseInt(document.querySelector('#weight').value)
    const result = document.querySelector('#result')

    if(height === '' || height<0 || isNaN(height)){
        result.innerHTML = "Please give valid height"
    }

    if(weight === '' || weight<0 || isNaN(weight)){
        result.innerHTML = "Please give valid Weight"
    }

    else{
        const bmi = (weight / Math.pow(height/100,2)).toFixed(2)
        result.innerHTML = `your BMI is ${bmi}`
    }

})
