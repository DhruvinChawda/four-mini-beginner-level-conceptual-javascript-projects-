let randomNumber = parseInt(Math.random()*100 + 1)

const submit = document.querySelector('#subt')
const userinput = document.querySelector('#guessfield')
const guessSlot = document.querySelector('.guesses')
const remaining = document.querySelector('.attempts')
const lowOrHigh = document.querySelector('.lowOrHi')
const startOver = document.querySelector('.resultparas')


const p = document.createElement('p')

let prevGuess = []
let numGuess = 1

let playGame = true  //necessary game chalu rakhne ke liye

if(playGame){
    submit.addEventListener('click',function(eve){
        eve.preventDefault()
        let userGuess = parseInt(userinput.value)
        validGuess(userGuess)

    })
}

function validGuess(guess){
    if(guess < 1 || guess > 100){
        alert('Please enter a number between 1 and 100')
    }
    else if(isNaN(guess)){
        alert('Please enter a valid number')
    }
    else{
        prevGuess.push(guess)
        if(numGuess === 11){
            displayGuess(guess)
            displayMessage(`Game Over. Random Number was ${randomNumber}`)
            endGame();
        }
        else{
            displayGuess(guess)
            checkGuess(guess)
        }
    }
}

function checkGuess(guess){
    if(guess === randomNumber){
        displayMessage(`Congratulations! You Guessed it right in ${numGuess} attempts.`)
        endGame();
    }
    else if(guess < randomNumber){
        displayMessage(`Go Higher`)
    }
    else if(guess > randomNumber){
        displayMessage(`Go Lower`)
    }
}

function displayMessage(message){
    lowOrHigh.innerHTML = `<h2>${message}</h2>`
}

function displayGuess(guess){
    userinput.value = ''              //value clean
    guessSlot.innerHTML += ` ${guess} ` // value show
    numGuess++;                       // value update
    remaining.innerHTML = `${11 - numGuess}`
}

function newGame(){
    
    const newGameButton = document.querySelector('#newGame')
    newGameButton.addEventListener('click',function(e){
        randomNumber = parseInt(Math.random()*100 + 1)
        prevGuess = []
        numGuess = 1
        guessSlot.innerHTML = ''
        remaining.innerHTML = '10'
        userinput.removeAttribute('disabled')
        startOver.removeChild(p)
        displayMessage(``)
        playGame = true;

    })
}

function endGame(){
    userinput.value = '';
    userinput.setAttribute('disabled', '');
    p.classList.add('button');
    p.innerHTML = `<h2 id ="newGame" > Start New Game </h2>`;
    startOver.appendChild(p);
    playGame = false;
    newGame();
}