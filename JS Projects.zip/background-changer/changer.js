const varbutt = document.querySelectorAll('.button');
const body = document.querySelector("body")

varbutt.forEach(function(button){
    console.log(button);
    button.addEventListener('click',function(eve){
        console.log(eve)
        console.log(eve.target);
        if(eve.target.id === 'grey'){
            body.style.background = 'grey';
        }
        else if(eve.target.id === 'white'){
            body.style.background = 'white';
        }
        else if(eve.target.id === 'blue'){
            body.style.background = 'blue';
        }
        else if(eve.target.id === 'red'){
            body.style.background = 'red';
        }
        else if(eve.target.id === 'yellow'){
            body.style.background = 'yellow';
        }

    });
});